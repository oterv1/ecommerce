<?php
   $db = mysqli_connect('localhost','root','','vaecommerce');

   if(mysqli_connect_errno()){
	   echo 'Database connection failed with following errors: '. mysqli_connect_error();
	   die();
   }
   
   
   define('BASEURL', '/Ecommerce/');
?>