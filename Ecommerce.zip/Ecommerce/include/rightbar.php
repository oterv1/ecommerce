<!--right side bar-->
	   
	   <div class="col-md-2">Right Side Bar</div>