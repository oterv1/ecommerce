</div><br/><br/>
  
   
   <div class="col-md-12 text-center" >&copy; Copyright 2019-2022 VA Corporation</div>
  <script>
   jQuery(window).scroll(function(){
	   var vscroll = jQuery(this).scrollTop();
	   jQuery('#logotext').css({
		   "transform" : "translate(0px, "+vscroll/2+"px)"
	   });
	   var vscroll = jQuery(this).scrollTop();
	   jQuery('#for-pic').css({
		   "transform" : "translate(0px, -"+vscroll/2+"px)"
	   });
	   
   });
   
   function detailsmodal(id){
	   
	  var data = {"id" : id};
	  jQuery.ajax({
		  url: <?=BASEURL; ?>+'include/detailsmodal.php',
		  method: "post",
		  data: data,
		  success: function(data){
			  jQuery('body').append(data);
			  jQuery('#details-modal').modal('toggle');
		  },
		  error: function(){
			  alert("Something went wrong.");
		  }
	  });
   }
  </script>
  
  </body>
</html>