<?php
   require_once '../core/init.php';
   include 'includes/head.php';
   include 'includes/navigation.php';
?>
 Brands
  <table class="table table-bordered table-striped">
    <thead>
	   <th></th><th>Brand</th><th></th>
	</thead>
	<tbody>
	  <tr>
	    <td><a href="brands.php?"></a></td> 
		<td>Express</td>
		<td></td>
	  </tr>
	</tbody>
  </table>
<?php
  include 'includes/footer.php';
?>