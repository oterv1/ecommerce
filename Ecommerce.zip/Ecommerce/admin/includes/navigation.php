<!--Top Nav Bar-->
    <nav class="navbar navbar-default navbar-fixed-top">
	  <div class="container">
	   <a href="/Ecommerce/admin/index.php" class="navbar-brand">Ann's Boutique Admin</a>
	    <ul class="nav navbar-nav">
		 
		  
		 <!--Menu Items-->
		  <li><a href="brands.php">Brands</a></li>
	<!--	 <li class="dropdown">
		  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $parent['category'];?><span class="caret"></span></a>
		  <ul class="dropdown-menu" role="menu">
		   
		    <li><a href="#"></a></li>
		   
		  </ul>
	     </li> -->
		  
		
	   </div>
      </nav>