<?php
   require_once '../core/init.php';
   include 'includes/head.php';
   include 'includes/navigation.php';
?>
 Administrator Home
<?php
  include 'includes/footer.php';
?>